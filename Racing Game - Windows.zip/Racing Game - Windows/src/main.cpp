#include "projectmenu.h"

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <filesystem>
#include <system_error>

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    wchar_t executablePath[32768];
    const DWORD length = GetModuleFileNameW(nullptr, executablePath, 32768);
    std::error_code directoryError;
    if (length > 0 && length < 32768)
        std::filesystem::current_path(
            std::filesystem::path(executablePath).parent_path(), directoryError);

    if (length == 0 || length >= 32768 || directoryError)
    {
        MessageBoxW(nullptr, L"Could not open the game folder.", L"Console Racing",
                    MB_OK | MB_ICONERROR);
        return 1;
    }

    return runMenu();
}
#else
int main()
{
    return runMenu();
}
#endif
